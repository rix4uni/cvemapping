const express = require('express');
const path = require('path');
const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Landing page with reflected XSS
app.get('/', (req, res) => {
  const q = req.query.q || '';
  res.render('landing', { query: q });
});

// Bookmarklet page — only accessible via valid XSS
app.get('/bookmarklet', (req, res) => {
  const referer = req.get('Referer');
  let q = '';

  if (referer && referer.includes('?q=')) {
    try {
      const queryString = referer.split('?')[1];
      const params = new URLSearchParams(queryString);
      q = params.get('q');
    } catch (e) {
      return res.status(403).send('Forbidden: Malformed Referer');
    }
  }

  // Expanded regex to match script, img, svg, iframe, and event handlers
  const validXSS = /(?:<(?:(?:script|iframe|svg|img|object|embed|math|video|audio)(?:\b|\/)[^>]*?)|\bon\w+\s*=)|(?:%3c(?:(?:script|iframe|svg|img|object|embed|math|video|audio)(?:%2f|%20|%09|%0a|%0d)[^%]*?)|%6f%6e\w+%3d)/i;

  if (referer && q && validXSS.test(q)) {
    res.render('bookmarklet');
  } else {
    res.status(403).send('Forbidden: Invalid access - XSS payload required');
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`XSSBOO challenge running on http://localhost:${PORT}`);
});
