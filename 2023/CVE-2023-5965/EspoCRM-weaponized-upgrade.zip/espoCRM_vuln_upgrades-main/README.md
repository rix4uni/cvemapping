# espoCRM_vuln_upgrades
EspoCRM 2.7.4 and earlier is vulnerable to an arbitrary file upload that can lead to code execution in the add upgrade functionality.

The zip file on this repo upload a web shell to /webshell.php
